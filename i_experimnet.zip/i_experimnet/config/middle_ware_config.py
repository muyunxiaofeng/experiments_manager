# -*- coding:utf-8 -*-
"""
README.md	项目名
PyCharm	集成开发环境
middle_ware_config	文件名
41379	用户名（指登录电脑的那个用户名）
2023/12/6	当前系统的年月日
11:59	当前系统的时分秒
2023	当前年份
12	当前月份（形式：07）
12月	当前月份（形式：7月）
十二月	当前月份（形式：七月）
06	当天
11	当前小时
59	当前分钟
58	当前秒钟
"""


class Digital_elisa_file_select_config:
    default_path = r"G:/"
